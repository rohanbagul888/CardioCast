# Early Detection of Heart Disease Using Big Data Approac

to view notebook at nbviewer for better clarity click [Early Detection of Heart Disease Using Big Data Approach](https://nbviewer.jupyter.org/github/shsarv/Heart-Disease-Prediction/blob/main/Early%20Detection%20of%20Heart%20Disease%20Using%20Big%20Data%20Approach.ipynb)
